<template>
    <div class="card h-100 w-100">
        <div class="embed-responsive embed-responsive-16by9" style="border: none">
            <router-link :to="{name: 'ShowDetails', params: {id: product.id}}">
                <img 
                    class="embed-responsive-item card-img-top"
                    :src="product.imageUrl"
                    alt="Card image cap" 
                />
            </router-link>
        </div>
        <div class="card-body">

            <router-link :to="{name: 'ShowDetails', params: {id: product.id}}">
                <h5 class="card-title">{{ product.name }}</h5>
            </router-link>

            <h6 class="card-title">R$ {{ product.price.toFixed(2) }}</h6>

            <p class="card-text">
                {{ product.description.substring(0, 65) }}...
            </p>
            <router-link :to="{name: 'EditProduct', params: {id: product.id}}" 
            v-show="$route.name == 'AdminProduct'">
                <a href="#" class="btn">Editar</a>
            </router-link>
        </div>
    </div>
</template>

<script>
    export default {
        name: "ProductBox",
        props: ["product"]
    }

</script>

<style scoped>
    .card-img-top {
        object-fit: cover;
    }
    a {
        text-decoration: none;
    }
    .card-title {
        color: #484848;
    }

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8;
        width: 150px;
        height: 45px;
    }

    /*
    .btn:active {
        background-color: #414141;
        color: #fff;
        border-color: rgb(7, 7, 7);
        box-shadow: 0px 0px 2px 5px #bfc9d8; 
    }
    */
    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:focus {
        box-shadow: none;
    }

</style>
