<template>
    <div class="card w-100 h-100" style="margin-top: 10px">
        <div class="embed-responsive embed-responsive-16by9 d-flex flex-column justify-content-center" style="border: none">
            <img class="embed-responsive-item card-img-top" :src="category.imageUrl" alt="Card image cap" />
        </div>
        <div class="card-body">
            
            <router-link :to="{name: 'ListProducts', params: {id: category.id}}">
                <h5 class="card-title">{{ category.categoryName }}</h5>
            </router-link>

            <p class="card-text">{{ category.description }}</p>

            <router-link :to="{name: 'EditCategory', params: {id: category.id}}"
                          v-if="$route.name == 'Category'">
                <a href="#" class="btn">Editar</a>
            </router-link>
            
        </div>
    </div>
</template>

<script>
    export default {
        name: "CategoryBox",
        props: ["category"],
        methods: {}
    }
</script>

<style scoped>
.card-img-top{
    object-fit: cover;
}

.btn {
    background-color: #ebebeb;
    color: #000;
    border-color: #bfc9d8;
    width: 80px;
    height: 40px;
}

/*
.btn:active {
    background-color: #414141;
    color: #fff;
    border-color: rgb(7, 7, 7);
    box-shadow: 0px 0px 2px 5px #bfc9d8; 
}
*/
.btn:active {
    background-color: #232F3E;
    color: #fff;
    box-shadow: none;
}
.btn:focus {
    box-shadow: none;
}

</style>