<template>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <!-- Navbar content -->
      <!--    Logo-->
      <router-link class="navbar-brand" :to="{ name: 'Home' }">
        <img id="logo" style="border-radius: 2px;" src="../assets/planeta_bola.png" />
      </router-link>
      <!--    Burger Button-->
      <button
        class="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <!--      Search Bar-->
        <form class="form-inline ml-auto mr-auto">
          <div class="input-group">
            <input
              size="100"
              type="text"
              class="form-control"
              placeholder="Buscar produtos..."
              aria-label="Username"
              aria-describedby="basic-addon1"
            />
            <div class="input-group-prepend">
              <span class="input-group-text" id="search-button-navbar">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="16"
                  height="16"
                  fill="currentColor"
                  class="bi bi-search"
                  viewBox="0 0 16 16"
                >
                  <path
                    d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"
                  />
                </svg>
              </span>
            </div>
          </div>
        </form>

        <!-- dropdown for browse -->
        <ul class="navbar-nav ml-auto">

          <li class="nav-item dropdown">
            <div class="nav-link text-light" style="display: flex; align-items: center;">
              
              <router-link class="nav-link text-light py-0" v-if="isLogged" style="margin-right: 5px; display: flex; align-items: center;" :to="{name: 'UserDetails'}"> Olá, {{userName}}! </router-link>
              
            </div>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-light" href="#" id="navbarAccount" data-toggle="dropdown" style="display: flex; align-items: center;">
              <div style="margin-right: 5px;">Navegar</div>
              <!-- Ícone do usuário <i class="bi bi-list" style="font-size: 40px;"></i>  -->
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarAccount">
              <router-link :to="{name: 'Home' }" class="dropdown-item">Home</router-link>
              <router-link :to="{name: 'AllProducts' }" class="dropdown-item">Produtos</router-link>
              <router-link :to="{name: 'Home' }" class="dropdown-item">Categoria</router-link>
            </div>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link text-light dropdown-toggle" href="#" id="navbarAccount" data-toggle="dropdown" style="display: flex; align-items: center;">
              <div style="margin-right: 5px;">Contas</div>
              <!-- Ícone do usuário <i class="bi bi-list" style="font-size: 40px;"></i>  -->
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarAccount">
              <router-link v-if="isAdmin" :to="{name: 'Admin' }" class="dropdown-item">Admin</router-link>
              <router-link v-if="isLogged" :to="{name: 'UserDetails' }" class="dropdown-item">Detalhes</router-link>
              <router-link v-if="isLogged" :to="{name: 'Wishlist' }" class="dropdown-item">Wishlist</router-link>
              <router-link v-if="!isLogged" :to="{name: 'Signup' }" class="dropdown-item">Registrar</router-link>
              <router-link v-if="!isLogged" :to="{name: 'Signin' }" class="dropdown-item">Entrar</router-link>
              <a class="dropdown-item" v-if="isLogged" href="#" @click="signout">Sair</a>
            </div>
          </li>

          <li class="nav-item">
            <div id="cart" style="position: relative">
              <span id="nav-cart-count" style="pointer-events: none;" v-if="cartCount > 0">{{ cartCount }}</span>
              <router-link class="text-light" :to="{name: 'Cart'}">
                <i class="fa fa-shopping-cart" style="font-size: 36px;"></i>
              </router-link>
            </div>
            
          </li>
        </ul>

        <!-- dropdown for account -->

      </div>
    </nav>
  </template>
  <script>

  import { mapMutations } from 'vuex';

  import swal from 'sweetalert';

  export default {
    name: "Navbar",
    props: ["cartCount", "isLogged", "userName", "isAdmin"],
    data() {
      return { 
      };
    },
    methods: {
      ...mapMutations(['checkIsLogged']), // Importando a mutation fetchData
      ...mapMutations(['resetCartCount']), // Importando a mutation fetchData
      signout() {
        localStorage.removeItem("token");
        localStorage.removeItem("userId");
        localStorage.removeItem("isAdmin");
        swal({
          text: "Você saiu",
          icon: "success",
        });
        this.checkIsLogged();
        this.resetCartCount();
        this.$router.push({name: "Home"});
      },
    },
    mounted() {
      console.log("montado");
      this.checkIsLogged();
    },
  };
  </script>
  <style scoped>
  #logo {
    width: 205px;
    margin-left: 5px;
    margin-right: 5px;
  }
  a {
    color: rgb(0, 0, 0);
  }
  .nav-link {
    color: white;
  }

  #search-button-navbar {
    background-color: rgb(230, 243, 255);
    border-color: rgb(230, 243, 255);
    border-top-right-radius: 2px;
    border-bottom-right-radius: 2px;
  }

  #nav-cart-count {
    background-color: red;
    color: white;
    border-radius: 50%;
    height: 15px;
    width: 15px;
    font-size: 15px;
    align-items: center;
    display: flex;
    justify-content: center;

    position: absolute;
    margin-left: 10px;
  }

  </style>