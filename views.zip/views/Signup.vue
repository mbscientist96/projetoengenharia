<template>
    <div class="container">

        <div class="row">
            <div class="col-12 text-center pt-3">
                <!-- display logo-->
            </div>
        </div>

        <!-- header-->

        <div class="row">
            <div class="col-12 justify-content-center flex-row d-flex pt-2">
                <div id="signup-div" class="flex-item-border border py-3">
                    <h2 class="pt-4 pl-4" style="text-align: center;">Crie sua conta</h2>
                    <form @submit="signup" class="pt-4 pl-4 pr-4">
                        <div class="form-group">
                            <label for="Email">Email</label>
                            <input type="email" v-model="email" class="form-control" required/>
                        </div>

                        <div class="form-row">
                            <div class="col-8">
                                <div class="form-group">
                                    <label>Nome</label>
                                    <input type="text" v-model="name" class="form-control" required/>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>CPF</label>
                                    <input type="number" v-model="cpf" class="form-control" required/>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-row">
                            <div class="col-8">
                                <div class="form-group">
                                    <label>Endereço</label>
                                    <input type="text" v-model="address" class="form-control" required/>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label>Número</label>
                                    <input type="number" v-model="number" class="form-control" required/>
                                </div>
                            </div>
                        </div>


                        <!--password-->
                        <div class="form-group">
                            <label for="Password">Telefone/Celular</label>
                            <input type="text" v-model="phone" class="form-control" required/>
                        </div>
                        <!--password-->
                        <div class="form-group">
                            <label for="Password">Senha</label>
                            <input type="password" v-model="password" class="form-control" required/>
                        </div>
                        <!--confirm password-->
                        <div class="form-group">
                            <label for="Password">Confirmar senha</label>
                            <input type="password" v-model="passwordConfirm" class="form-control" required/>
                        </div>
                        <div class="pt-3 pb-4 d-flex align-items-center justify-content-center">
                            <button class="btn mt-2">Criar conta</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- form -->

    </div>
</template>
<script>

    import axios from 'axios'
    import swal from 'sweetalert';

    export default {
        
        props: ["baseURL"],
        data() {
            return {
                email: null,
                name: null,
                cpf: null,
                address: null,
                phone: null,
                number: null,
                password: null,
                passwordConfirm: null
            }
        },
        mounted() {
            if(localStorage.getItem("token") != null) {
                console.log("logado indo para a home");
                this.$router.push({name: "Home"});
            }
        },
        methods: {
            async signup(e) {
                e.preventDefault();
                if (this.password === this.passwordConfirm) {
                    // call signup api
                    const user = {
                        email: this.email,
                        name: this.name,
                        cpf: this.cpf,
                        address: this.address,
                        number: this.number,
                        phone: this.phone,
                        password: this.password
                    };

                    try {
                        await axios.post(`${this.baseURL}user/signup`, user);
                        this.$router.replace("/");
                        swal({
                            text: 'Usuário registrado, por favor faça o login',
                            icon: 'success',
                        });
                    } catch (error) {
                        if (error.response.data === 'user already present') {
                            // Usuário já existe, mostrar uma mensagem de erro
                            swal({
                                text: 'Esse usuário já existe',
                                icon: 'error',
                            });
                        } else {
                            console.error("problema:", error);
                        }
                    }
                } else {
                    // show some error
                    swal({
                            text: 'As senhas não correspondem',
                            icon: 'error',
                    });
                }
            },
            
        },
    };

</script>

<style scoped>

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8;
        width: 180px;
        height: 45px;
    }

    /*
    .btn:active {
        background-color: #414141;
        color: #fff;
        border-color: rgb(7, 7, 7);
        box-shadow: 0px 0px 2px 5px #bfc9d8; 
    }
    */
    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:focus {
        box-shadow: none;
    }

    .border {
        border-style: solid;
        background-color: #f7f7f7f5;
        border-radius: 5px;
        margin-top: 50px;
    }

    @media screen {
        #signup-div {
            width: 50%;
        }
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }

    /* Firefox */
    input[type=number] {
    -moz-appearance: textfield;
    }

    textarea:focus,
    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="datetime"]:focus,
    input[type="datetime-local"]:focus,
    input[type="date"]:focus,
    input[type="month"]:focus,
    input[type="time"]:focus,
    input[type="week"]:focus,
    input[type="number"]:focus,
    input[type="email"]:focus,
    input[type="url"]:focus,
    input[type="search"]:focus,
    input[type="tel"]:focus,
    input[type="color"]:focus,
    .uneditable-input:focus {   
    border-color: rgba(31, 46, 88, 0.8);
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
    outline: 0 none; }


</style>
