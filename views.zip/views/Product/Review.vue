<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Revisão</h3>
            </div>
        </div>
            <!-- loop over the cart items and display -->
            
            <div v-for="cartItem in cartItems" :key="cartItem.id" class="row mt-2 pt-3 justify-content-start">
                <div class="col-3"></div>
                <div class="col md-3 embed-responsive embed-responsive-16by9">
                    <img :src="cartItem.product.imageUrl" alt="" class="w-100 card-image-top embed-responsive-item"
                    style="object-fit: cover;"
                    />
                </div>

                <!-- display product name and quantity -->
                <div class="col-md-5 px-3">
                    <div class="card-block px-2">
                        <h6 class="card-title" >
                            <router-link :to="{name: 'ShowDetails', params:{id: cartItem.product.id}}">
                                {{cartItem.product.name}}
                            </router-link>
                        </h6>
                        
                        <p class="mb-0 font-weight-bold" id="item-price">
                            R$ {{ cartItem.product.price.toFixed(2) }} por unidade
                        </p>
                        <p class="mb-0" style="float:left">
                            Quantidade: {{ cartItem.quantity }}
                        </p>
                        <p class="mb-0" style="float:right">
                            Total: <span class="font-weight-bold">
                                $ {{ (cartItem.product.price * cartItem.quantity).toFixed(2) }}
                            </span>
                        </p>
                        <br/>
                    </div>
                </div>

                <div class="col-2"></div>
                <div class="col-12"><hr /></div>

            </div>

            

                <!-- display the price -->
            <div class="total-cost pt-4 text-right">
                <h5>Total : R$ {{ totalCost.toFixed(2) }}</h5>
            </div>

            <div class="row">
                <div class="col-2">
                    <div id="qrcode">
                        <img :src="qrurl" alt="">
                    </div>
                </div>
                <div class="pl-5 col-2 ml-5">
                    <p class="font-weight-bold txt" style="font-size: 25px;"> Finalize sua compra com o QR Code ao lado</p>
                    <p class="font-weight-bold txt"> Usuário: {{ name }}</p>
                    <p class="font-weight-bold txt"> Email: {{ email }}</p>
                    <p class="font-weight-bold txt"> Endereço: {{ address }}, {{ number }}</p>
                </div>
                
            </div>
        </div>
</template>

<script >

import axios from 'axios';
import { mapState } from 'vuex';
    const QRCode = require('qrcode');
    
    export default {
        data() {
            return {
                cartItems: {},
                token: null,
                totalCost: 0,
                address: null,
                cpf: null,
                email: null,
                name: null,
                number: null,
                phone: null,
                qrurl: null,
            };
        },
        computed: {
                ...mapState({
                baseURL: state => state.baseURL,
                admin: state => state.admin,
            })
        },  

        methods: {
            // fetch all itens in cart
            listCartItens() {
                axios.get(`${this.baseURL}cart/get/?token=${this.token}`)
                .then(res => {
                    const result = res.data;
                    this.cartItems = result.cartItems;
                    this.totalCost = result.totalCost;
                })
                .catch((err) => console.log("err", err));
            },
            openLink() {
                
                    this.$router.push({name: "Review"});
            },
            deleteItem(itemId) {
                axios
                .delete(`${this.baseURL}cart/delete/${itemId}/?token=${this.token}`)
                .then((res) => {
                    if (res.status == 200) {
                        this.$router.go(0);
                    }
                })
                .catch((err) => console.log("err", err));
            },
            async generateQRCode() {
                
                let adminData = null;

                await axios.get(this.baseURL + "user/getadmin/")
                .then(res =>  {
                    adminData = res.data
                }).catch(err => {console.log(err)});                

                if(adminData.phone) {

                    const paymentLink = "https://wa.me/"+adminData.phone+"?text=Olá! Gostaria de fazer um pagamento.";

                    QRCode.toDataURL(paymentLink, (err, url) => {
                        if (err) {
                            console.error(err);
                            return;
                        }
                        
                        // Aqui você pode usar a URL gerada como src de uma tag de imagem
                        this.qrurl = url;
                        console.log(url);
                    });
                }
            }
        },
        mounted() {
            this.token = localStorage.getItem("token");
            this.listCartItens();

            this.userId = localStorage.getItem("userId");
            if (this.userId) {
                this.generateQRCode();
            axios
                .get(this.baseURL + `user/${this.userId}`)
                .then(res =>  {
                    const result = res.data;
                    
                    this.address = result.address
                    this.cpf = result.cpf;
                    this.email = result.email;
                    this.name = result.name;
                    this.number = result.number;
                    this.phone = result.phone;

                }).catch(err => {console.log(err)});
            }
        }
    };
</script>

<style scoped>

    h4, h5 {
        color: #484848;
        font-size: 700;
    }
    .txt {
        white-space: nowrap;
    }

</style>