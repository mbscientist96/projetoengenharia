<template>
    
    <div class="container">
        <div class="image">
            <img :src="product.imageUrl" alt="Produto" class="img-fluid fixed-size-img mb-3 ">
            <p class="title-description mt-5"> Características do produto</p>
            <p class="text-description mt-3"> {{ product.description }}</p>
        </div>
        
        <div class="product-description">
            <h2 class="product-title">{{ product.name }}</h2>
            <p class="product-title" style="font-size: small;">{{ category.categoryName }}</p>
            <p class="font-weight-bold"> R$ {{ parseFloat(product.price).toFixed(2) }}</p>
            <p><span class="payment-method">Meios de Pagamento:</span> <a href="https://wa.me/seu-numero-de-telefone" target="_blank" class="whatsapp-link"><img src="../../assets/whatsicon.png" alt="WhatsApp">WhatsApp</a></p>
           <div>

      
           </div>
           <br>
            <div class="quantity-container">
                <label for="quantity"  class="quantity-label input-group-text">Quantidade</label>
                
                <div style="transform: translateX(-10px);">
                    <input type="text" id="quantity" v-model="quantity" class="quantity-input" readonly>
                    <button class="btn" @click="incrementQuantity" style="width: 40px;">+</button>
                    <button class="btn" @click="decrementQuantity" style="width: 40px;">-</button>
                </div>
            </div>
           <br>
            <button class="btn" style="margin-right: 10px;" @click="addToCart">Adicionar ao carrinho </button>
            <button class="btn" @click="addToWishlist">{{wishListString}}</button>
        </div>

    </div>

    <div class="col mt-2 pt-3 justify-content-around">

        <textarea v-model="commentarytext" class="commentary mb-3 col md-3 textareacommentary"></textarea>
        <button class="btn" @click="addCommentary"> Comentar </button>
        <button v-if="isAdmin" class="btn" @click="removeAllCommentaries"> Remover todos os comentarios </button>

        <div v-for="commentary in commentaries" :key="commentary.id" class="commentary mb-3">
            <h2 class="commentary-text col md-3">{{ commentary.username }}: {{ commentary.description }}</h2>
        </div>
    </div>

    
</template>

<script>

import swal from 'sweetalert'
import axios from 'axios'
import { mapState } from 'vuex';

    export default {
        data() {
            return {
                isAdmin: false,
                commentarytext: null,
                product: {},
                category: {},
                commentaries: [],
                quantity: 1,
                wishListString: "Adicionar à wishlist"
            }
        },
        props: ["baseURL", "products", "categories"],
        methods: {

            incrementQuantity() {
                this.quantity++;
            },

            decrementQuantity() {
                if (this.quantity > 1) {
                    this.quantity--;
                }
            },

            async getAllCommentaries() {
                await axios.get(`${this.baseURL}commentary/${this.id}`)
                .then(res =>  {
                    this.commentaries = res.data
                }).catch(err => {console.log(err)});
            },
            
            async removeAllCommentaries() {

                await axios.get(`${this.baseURL}commentary/delete/${this.id}`)
                .then({}).catch(err => {console.log(err)});
                swal({
                        text: "Comentarios removidos",
                        icon: "success",
                    });
            },

            async addCommentary() {

                if (!this.token) {
                    swal({
                        text: "Por favor, faça o login para comentar",
                        icon: "error",
                    });
                    return;
                }

                    const newCommentary = {
                    productId: this.id,
                    description: this.commentarytext,
                    username: this.username,
                }

                axios.post(this.baseURL+"/commentary/create", newCommentary)
                .then(() => {
                    this.$emit("fetchData");
                    swal({
                        text: "Comentario adicionado com sucesso",
                        icon: "success"
                    })
                }).catch((err) => {
                    console.error(err);
                })
            },

            addToWishlist() {
                if (!this.token) {
                    // user is not logged in
                    // show some error
                    swal({
                        text: "Por favor, faça o login para adicionar à wishlist",
                        icon: "error",
                    });
                    return;
                }
                // add item to wish list
                axios.post(`${this.baseURL}wishlist/add?token=${this.token}`, {
                    id: this.product.id
                }).then((res) => {
                    if (res.status == 201) {
                        
                        this.wishListString = "Adicionado à wishlist";
                        swal({
                            text: "Adicionado à wishlist",
                            icon: "success",
                        });
                    }
                }).catch(err => {
                    console.log("err: ", err);
                });
            },

            // add to cart

            addToCart() {
                if (!this.token) {
                    // user is not logged in
                    // show some error
                    swal({
                        text: "Por favor, faça o login para adicionar ao carrinho",
                        icon: "error",
                    });
                    return;
                }

                // add to cart

            axios.post(`${this.baseURL}/cart/add?token=${this.token}`, {
                    productId: this.id,
                    quantity: this.quantity
                }).then((res) => {
                    if (res.status == 201) {
                        swal({
                            text: "Produto adicionado ao carrinho",
                            icon: "success",
                        });
                        this.$emit("fetchData");
                    }
                })
                .catch(err => {
                    console.log("err", err);
                });
            },
        },
        mounted() {
            console.log("teste");
            this.id = this.$route.params.id;
            this.product = this.products.find((product) => product.id == this.id);
            this.category = this.categories.find(category => category.id == this.product.categoryId);
            this.token = localStorage.getItem("token");
            this.isAdmin = localStorage.getItem("isAdmin");

            if (!this.isAdmin) {
                this.isAdmin = false;
            }

            if (this.isAdmin == "true") {
                this.isAdmin = true;
            } else {
                this.isAdmin = false;
            }
            this.getAllCommentaries();
        },
        computed: {
                ...mapState({
                username: state => state.userName,
            })
        },  
    };

</script>

<style scoped>

    .category {
        font-weight: 400;
    }

    #wishlist-button {
        background-color: #b9b9b9;
    }

    #add-to-cart-button {
        background-color: #febd69;
    }

    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
    -webkit-appearance: none;
    margin: 0;
    }

    /* Firefox */
    input[type=number] {
    -moz-appearance: textfield;
    }

 
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
        }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 20px;
            background-color: #2a8dae;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        header a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            transition: color 0.3s ease;
        }
        header a:hover {
            color: #ffd700; 
        }
        h1, h3 {
            margin: 0;
            color: #fff;
        }
        h1 {
            font-size: 28px;
            margin-right: 20px; 
        }
        h3 {
            font-size: 18px;
            opacity: 0.8; 
        }
        .search-container {
            position: relative;
            width: calc(80% - 300px); 
            margin: 0 auto; 
        }
        .search-box {
            width: calc(100% - 40px);
            margin: 0 auto;
            padding: 10px 40px 10px 20px;
            border-radius: 20px;
            border: none;
            font-size: 16px;
            background-color: #fff; 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); 
        }
        .search-icon {
            position: absolute; 
            top: 50%; 
            right: 10px;
            transform: translateY(-50%); 
            width: 20px; 
            height: auto; 
            cursor: pointer;
        }
        .icon {
            width: 40px;
            height: 40px;
            border-radius: 50%; 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
        nav {
            display: flex;
            align-items: center;
        }
        nav a {
            margin-left: 20px;
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            margin-top: 20px;
        }
        .image {
            margin-right: 20px;
        }
        .image img {
            width: 350px; 
            height: auto;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.5);
            transition: transform 0.3s ease;
        }
        .image:hover img {
            transform: scale(1.1);
        }
        .product-description {
            flex-grow: 1;
            margin-top: 20px;
            text-align: left;
        }
        .product-description h2 {
            margin-top: 0;
            font-size: 24px;
            color: #333;
            margin-bottom: 10px;
        }
        .product-title {
        font-size: 28px;
        color: #333;
        font-weight: bold;
        font-family: 'Arial Black', sans-serif;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }
        .product-description p {
            font-size: 16px;
            color: #555;
            line-height: 1.6;
        }
        .buy-button {
    background-color: #2a8dae;
    color: #fff;
    border: none;
    border-radius: 5px;
    padding: 10px 20px;
    font-size: 18px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

.buy-button:hover {
    background-color: #1e6d87;
}
.payment-method {
    color: blue;
}

.whatsapp-link {
    color: green;
    text-decoration: none;
}

.whatsapp-link img {
    vertical-align: middle;
    width: 20px; /* ajuste o tamanho conforme necessário */
    height: 20px; /* ajuste o tamanho conforme necessário */
    margin-right: 5px;
}
.quantity-container {
        display: flex;
        align-items: center;
    }

    .quantity-label {
        margin-right: 10px;
        font-size: 16px;
    }

    .quantity-input {
        width: 50px;
        padding: 5px;
        text-align: center;
        font-size: 16px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }

    .quantity-button {
        width: 30px;
        height: 30px;
        background-color: #2a8dae;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        margin: 0 5px;
    }

    .quantity-button:hover {
        background-color: #1e6d87;
    }
    .title-description {
        font-size: 20px;
        color: #242424;
        font-weight: bold;
        font-family: 'Arial', sans-serif;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }

    .text-description {
        font-size: 12px;
        color: #242424;
        font-weight: bold;
        font-family: 'Arial', sans-serif;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }

    .itens-description {
        font-size: 16px;
        color: #555;
        font-family: 'Arial', sans-serif;
        margin-bottom: 5px;
    }

    .itens-description span {
        font-weight: bold;
        color: #2a8dae;
    }
    .itens-description:not(span) {
        font-style: italic;
        color: #393232;
    }
    .size-select {
        font-size: 16px;
        padding: 5px;
        border: 1px solid #ccc;
        border-radius: 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        appearance: none;
        -webkit-appearance: none;
        -moz-appearance: none;
        background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="10" height="5"><polygon points="0,0 10,0 5,5" fill="#2a8dae"/></svg>');
        background-repeat: no-repeat;
        background-position: right 10px center;
    }



    .fixed-size-img {
        object-fit: cover;
        width: 120px;
        min-height: 300px;
        max-height: 120px;
        float: left;
        margin: 10px;
        padding: 3px;
    }

    .size-select:focus {
        outline: none;
        border-color: #2a8dae; /* Cor quando selecionado */
    }

    .commentary {
        margin-top: 10px;
        margin-bottom: 20px;
    }

    .commentary-text {
        font-size: 16px;
        margin-bottom: 5px;
        text-align: center;
    }

    .textareacommentary {

        text-align: justify;
    }

</style>
