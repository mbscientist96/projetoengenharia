<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h4 class="pt-3">Editar Produto</h4>
            </div>
        </div>
        <div class="row">
            
            <div class="col-3"></div>
            <div class="col-6">
                <form v-if="product" @submit="editProduct">
                    <div class="form-group">
                        <label>Categoria</label>
                        <select class="form-control" v-model="product.categoryId" required>
                            <option v-for="category of categories" 
                                :key="category.id"
                                :value="category.id"> {{ category.categoryName }}
                            </option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Nome</label>
                        <input type="text" class="form-control" v-model="product.name" required/>
                    </div>
                    <div class="form-group">
                        <label>Descrição</label>
                        <textarea type="textarea" class="form-control" v-model="product.description" required></textarea>
                    </div>
                    <div class="form-group">
                        <label>Imagem URL</label>
                        <input type="text" class="form-control" v-model="product.imageUrl" required/>
                    </div>
                    <div class="form-group">
                        <label>Preço</label>
                        <input type="value" class="form-control" v-model="product.price" required/>
                    </div>
                    <button type="submit" class="btn">Salvar</button>
                </form>
            </div>
            <div class="col-3"></div>
        </div>
    </div>
</template>

<script>

import axios from 'axios'
import swal from 'sweetalert'

export default {
    data() {
            return {
                product: null,
                id: null
            }
        },
    props: ["baseURL", "products", "categories"],

    methods: {
        async editProduct(e) {
            e.preventDefault();
            console.log('product', this.product);
            await axios.post(`${this.baseURL}product/update/${this.id}`,
                    this.product)
                .then(() => {
                    this.$emit("fetchData");
                    this.$router.push({name: 'AdminProduct'})
                    swal({
                        text: "O produto foi atualizado com sucesso",
                        icon: "success"
                    })
                }).catch((err) => {
                    console.log('err', err);
                })
        }
    },
    mounted() {
        this.id = this.$route.params.id;
        this.product = this.products.find(product => product.id == this.id);
    }
}

</script>

<style scoped>

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8
    }

    /*
    .btn:active {
        background-color: #414141;
        color: #fff;
        border-color: rgb(7, 7, 7);
        box-shadow: 0px 0px 2px 5px #bfc9d8; 
    }
    */
    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:focus {
        box-shadow: none;
    }

    textarea:focus {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    select:focus {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    select:active {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

</style>
