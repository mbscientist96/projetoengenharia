<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h3 class="pt-3">Carrinho de compras</h3>
            </div>
        </div>
            <!-- loop over the cart items and display -->
            
            <div v-for="cartItem in cartItems" :key="cartItem.id" class="row mt-2 pt-3 justify-content-around">
                <div class="col-2"></div>
                <div class="col md-3 embed-responsive embed-responsive-16by9">
                    <img :src="cartItem.product.imageUrl" alt="" class="w-100 card-image-top embed-responsive-item"
                    style="object-fit: cover;"
                    />
                </div>

                <!-- display product name and quantity -->
                <div class="col-md-5 px-3">
                    <div class="card-block px-2">
                        <h6 class="card-title" >
                            <router-link :to="{name: 'ShowDetails', params:{id: cartItem.product.id}}">
                                {{cartItem.product.name}}
                            </router-link>
                        </h6>
                        
                        <p class="mb-0 font-weight-bold" id="item-price">
                            R$ {{ cartItem.product.price.toFixed(2) }} por unidade
                        </p>
                        <p class="mb-0" style="float:left">
                            Quantidade: {{ cartItem.quantity }}
                        </p>
                        <p class="mb-0" style="float:right">
                            Total: <span class="font-weight-bold">
                                $ {{ (cartItem.product.price * cartItem.quantity).toFixed(2) }}
                            </span>
                        </p>
                        <br/>
                        <a href="#" class="text-right" @click="deleteItem(cartItem.id)">Remover do carrinho</a>
                    </div>
                </div>

                <div class="col-2"></div>
                <div class="col-12"><hr /></div>

            </div>

                <!-- display the price -->
            <div class="total-cost pt-4 text-right">
                <h5>Total : R$ {{ totalCost.toFixed(2) }}</h5>
            </div>
            <div style="transform: translateY(-25px);">
                <button class="btn btn-lg " @click="openLink">Finalizar compra</button>
            </div>

        </div>
</template>

<script>
import axios from 'axios';
import swal from 'sweetalert';

    export default {
        data() {
            return {
                cartItems: {},
                token: null,
                totalCost: 0,
            };
        },

        props: ["baseURL"],
        methods: {
            // fetch all itens in cart
            listCartItens() {
                axios.get(`${this.baseURL}cart/get/?token=${this.token}`)
                .then(res => {
                    const result = res.data;
                    this.cartItems = result.cartItems;
                    this.totalCost = result.totalCost;
                })
                .catch((err) => console.log("err", err));
            },
            openLink() {
                //<window.location.href = "https://wa.me/seu-numero-de-telefone";>
                    if(this.cartItems.length > 0) {
                        this.$router.push({name: "Review"});
                    } else {
                        swal({
                            text: "Adicione produtos ao carrinho",
                            icon: "error",
                        });
                    }
            },
            deleteItem(itemId) {
                axios
                .delete(`${this.baseURL}cart/delete/${itemId}/?token=${this.token}`)
                .then((res) => {
                    if (res.status == 200) {
                        this.$router.go(0);
                    }
                })
                .catch((err) => console.log("err", err));
            },
        },
        mounted() {
            this.token = localStorage.getItem("token");
            this.listCartItens();
        }
    };
</script>

<style scoped>

    h4, h5 {
        color: #484848;
        font-size: 700;
    }

</style>