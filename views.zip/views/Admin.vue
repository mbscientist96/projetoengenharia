<template>
    <div class="container py-4 text-center">
        <router-link :to="{name : 'Category'}">
            <button class="btn btn-lg mt-4 w-50"> Gerenciar categorias </button>
        </router-link>
        <br />
        <router-link :to="{name : 'AdminProduct'}">
            <button class="btn btn-lg mt-4 w-50"> Gerenciar produtos </button>
        </router-link>  
    </div>
</template>


<script>
    export default {

    }
</script>

<style>
/*
.btn {
    margin-bottom: 20px;
    width: 300px;
    height: 50px;
    background-color: #606c84;
    border-color: #606c84;
    color: white;
}
*/
textarea:focus,
    input[type="text"]:focus,
    input[type="textarea"]:focus,
    input[type="password"]:focus,
    input[type="datetime"]:focus,
    input[type="datetime-local"]:focus,
    input[type="date"]:focus,
    input[type="month"]:focus,
    input[type="time"]:focus,
    input[type="week"]:focus,
    input[type="number"]:focus,
    input[type="email"]:focus,
    input[type="url"]:focus,
    input[type="search"]:focus,
    input[type="tel"]:focus,
    input[type="color"]:focus,

    .uneditable-input:focus {   
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    textarea:focus {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8
    }

    /*
    .btn:active {
        background-color: #414141;
        color: #fff;
        border-color: rgb(7, 7, 7);
        box-shadow: 0px 0px 2px 5px #bfc9d8; 
    }
    */
    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }
    .btn:focus {
        box-shadow: none;
    }

</style>