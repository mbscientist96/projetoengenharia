<template>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h4 class="text-center py-3">Detalhes da conta</h4>
            </div>
        </div>
    </div>

    <div class="row user-details">
            <div class="col-12 justify-content-center flex-row d-flex pt-3">
                <div id="user-details" class="py-3">
                    <div class="form-row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Email</label>
                                <label class="user-text"> {{ this.email }} </label>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Telefone/Celular</label>
                                <label class="user-text"> {{ this.phone }} </label>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Nome</label>
                                <label class="user-text"> {{ this.name }} </label>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>CPF</label>
                                <label class="user-text"> {{ this.cpf }} </label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Endereço</label>
                                <label class="user-text"> {{ this.address }} </label>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Número</label>
                                <label class="user-text"> {{ this.number }} </label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


</template>

<script>
    import axios from 'axios';
    import { mapState  } from 'vuex';

    export default {
        computed: {
        ...mapState({
         baseURL: state => state.baseURL,
        })
    },

        data() {
            return {
                address: null,
                cpf: null,
                email: null,
                name: null,
                number: null,
                phone: null,
            }
        },
        mounted() {
            this.userId = localStorage.getItem("userId");
            if (this.userId) {
            axios
                .get(this.baseURL + `user/${this.userId}`)
                .then(res =>  {
                    const result = res.data;
                    
                    this.address = result.address
                    this.cpf = result.cpf;
                    this.email = result.email;
                    this.name = result.name;
                    this.number = result.number;
                    this.phone = result.phone;

                }).catch(err => {console.log(err)});
            }
        }

    }
</script>

<style>

    .user-details {
        margin-bottom: 500px;
    }

    .user-text {
        display: block;
        margin-top: .1rem; 
        border: 1px solid #ced4da;
        border-radius: 5px;
        padding: 6px;
        padding-right: 230px;
        background-color: #e9ecef;
        white-space: nowrap;
    }
    

</style>
