<template>
    <div class="container">
        <div class="row">
            <div class="col-12 text-center">
                <h4 class="pt-3">Editar categoria</h4>
                
                <div class="row">
                    <div class="col-3"></div>
                    <div class="col-6">
                        <form v-if="category" @submit="editCategory">
                            <div class="form-group">
                                <label>nome da categoria</label>
                                <input type="text" class="form-control" v-model="category.categoryName" required/>
                            </div>
                            <div class="form-group">
                                <label>Descrição</label>
                                <textarea type="text" class="form-control" v-model="category.description" required></textarea>
                            </div>
                            <div class="form-group">
                                <label>Imagem URL</label>
                                <input type="text" class="form-control" v-model="category.imageUrl" required/>
                            </div>
                            <button type="submit" class="btn">Salvar</button>
                        </form>
                    </div>
                    <div class="col-3"></div>
                </div>

            </div>
        </div>
    </div>
</template>

<script>

import axios from 'axios'
import swal from 'sweetalert'

    export default {
        data() {
            return {
                category: null,
                id: null
            }
        },
        props: ["baseURL", "categories"],
        methods: {
            async editCategory(e) {
                e.preventDefault();
                delete this.category["product"]
                console.log('category', this.category);

                await axios.post(`${this.baseURL}category/update/${this.id}`,
                    this.category)
                .then(() => {
                    this.$emit("fetchData");
                    this.$router.push({name: 'Category'})
                    swal({
                        text: "A categoria foi atualizada com sucesso",
                        icon: "success"
                    })
                }).catch((err) => {
                    console.log('err', err);
                })
            }
        },
        mounted() {
            this.id = this.$route.params.id;
            this.category = this.categories.find(category => category.id == this.id);
        }
    }

</script>

<style scoped>

    textarea:focus {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8
    }

    /*
    .btn:active {
        background-color: #414141;
        color: #fff;
        border-color: rgb(7, 7, 7);
        box-shadow: 0px 0px 2px 5px #bfc9d8; 
    }
    */
    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:focus {
        box-shadow: none;
    }

</style>
