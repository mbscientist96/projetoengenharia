

<template>
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h3 class="pt-3">Adicionar categoria</h3>
        </div>
      </div>
      <div class="row">
        <div class="col-3"></div>
        <div class="col-6">
          <form @submit="addCategory">
            <div class="form-group">
              <label>Nome</label>
              <input type="text" class="form-control" v-model="categoryName" required/>
            </div>
            <div class="form-group">
              <label>Descrição</label>
              <textarea type="text" class="form-control" v-model="description" required></textarea>
            </div>
            <div class="form-group">
              <label>Imagem URL</label>
              <input type="text" class="form-control" v-model="imageUrl" required/>
            </div>
            <!-- <button type="button" class="btn" @click="addCategory">Submit</button> -->
            <button class="btn">Adicionar categoria</button>
          </form>
        </div>
        <div class="col-3"></div>
      </div>
    </div>
  </template>
  <script>

  import axios from 'axios';
  import sweetalert from 'sweetalert';
  import { mapMutations } from 'vuex';

  export default {
    data() {
      return {
        categoryName: "",
        description: "",
        imageUrl: "",
      };
    },
    methods: {
      ...mapMutations(['fetchData']), // Importando a mutation setCategories
      addCategory(e) {
          e.preventDefault();
          console.log("aaaaaaaaaa")
          // dados
          const newCategory = {
              categoryName: this.categoryName,
              description: this.description,
              imageUrl: this.imageUrl,
          };
          //JSON.stringify(newCategory),
          
          // url
          const baseURL = "http://localhost:8082";
          const url = baseURL + "/category/create";

          // options
          const options = {
              headers: {
                  'Content-Type': 'application/json',
              }
          };
        
          axios.post(url, JSON.stringify(newCategory), options)
          .then(() => {
              console.log("adadada");
              sweetalert({
                  text: "Categoria adicionada com sucesso",
                  icon: "success",
              });
              
              this.fetchData();

              this.categoryName = '';
              this.description = '';
              this.imageUrl = '';

          })
          .catch(error => {
              console.log(error);
          })
      },
    },
  };
  </script>
  <style scoped>

    textarea:focus {
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }
  </style>
  