<template>
  <div id="home">
    <div id="background-div" class="">
      <div class="container py-5">
        <header class="text-left text-white py-5">
            <h3 class="mb-4 rounded" id="heading">
              <a href="#start-shopping" class="bg-white px-2 py-2 rounded">Comece a comprar</a>
            </h3>
            <p class="lead mb-0 bg-dark p-1 rounded"> Planeta Bola E-Commerce</p>
        </header>
      </div>

    </div>

    <!-- Display categories-->
    <div class="container">
      <div class="row">
        <div class="col-12 text-center">
          <h2 class="pt-3" id="start-shopping">Categorias</h2>
        </div>
      </div>
      <div class="row">
          <div v-for="index in this.categorySize" :key="index"
                class="col-md-6 col-xl-4 col-12 pt-3 justify-content-around d-flex">
          <CategoryBox :category="categories[index-1]" />
        </div>
      </div>
    </div>

  <!-- Display top products -->

    <div class="container py-2">
      <div class="row">
        <div class="col-12 text-center">
          <h2 class="pt-3">Principais destaques</h2>
        </div>
      </div>

      <!-- display products -->
      <div class="row">
          <div v-for="index in this.productSize" :key="index"
                class="col-md-6 col-xl-4 col-12 pt-3 justify-content-around d-flex">
          <ProductBox :product="products[index-1]" />
        </div>
      </div>
    </div>


  </div>
</template>

<script>

import CategoryBox from '../components/Category/CategoryBox.vue';
import ProductBox from '../components/ProductBox.vue';

export default {
  name: 'Home',
  components: {CategoryBox, ProductBox},
  props: ["categories", "products"],
  computed: {
    categorySize() {
      return this.categories.length;
    },
    productSize() {
      return Math.min(9, this.products.length);
    }
  },
  data() {
    return {

    }
  },
  mounted() {

  }
};
</script>

<style>
  .page-holder {
    min-height: 100vh;
  }
  .bg-cover {
    background-size: cover !important;
  }
  #background-div {
    background: url("../assets/background-clean.jpg");
    background-size: cover;
    height: 50vh /* Define a altura como 50% da altura da viewport */
  }

  #heading {
    font-weight: 400;
  }

</style>
