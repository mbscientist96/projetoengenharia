<template>
    <div class="container">
        <div class="row">
            <div class="col-12 justify-content-center d-flex flex-row pt-5">
                <div id="signin" class="flex-item-border border py-1">
                    <h2 class="pt-4" style="text-align: center;">Login</h2>
                    <form @submit="signin" class="form-group pt-4 pl-4 pr-4">
                        <div class="form-group">
                            <label>Email</label>
                            <input v-model="email" type="email" class="form-control"/>
                        </div>
                        <div class="form-group">
                            <label>Senha</label>
                            <input v-model="password" type="password" class="form-control"/>
                        </div>
                        <div class="pt-3 pb-3 d-flex align-items-center justify-content-center">
                            <button class="btn mt-2 py-0">Continuar</button>
                        </div>

                        <div class="row justify-content-center register-link">
                            <router-link :to="{name: 'Signup'}" class="custom-router-link">
                                Não possui uma conta? Registre-se aqui
                            </router-link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

    import axios from 'axios'
    import swal from 'sweetalert'

    export default {
        props: ["baseURL"],
        data() {
            return {
                email: null,
                password: null,
            }
        },
        methods: {
            async signin(e) {
                e.preventDefault();
                console.log("logando...");
                const body = {
                    email: this.email,
                    password: this.password,
                    userId: this.userId
                };
                await axios.post(`${this.baseURL}user/signin`, body)
                .then((res) => {
                    localStorage.clear();
                    localStorage.setItem("token", res.data.token);
                    localStorage.setItem("userId", res.data.userId);
                    

                    console.log("login efetuado");
                    swal({
                        text: "Usuário logado com sucesso",
                        icon: "success",
                    });
                    this.$emit("fetchData");
                    this.$router.push({name: "Home"});
                })
                .catch((err) => console.log("err", err));
            },
        },
        mounted() {
            if(localStorage.getItem("token") != null) {
                console.log("logado indo para a home");
                this.$router.push({name: "Home"});
            }
        }
    };
</script>

<style scoped>

    .border {
        border-style: solid;
        background-color: #f7f7f7f5;
        border-radius: 5px;
        margin-top: 50px;
    }

    @media screen {
        #signin {
            width: 40%;
        }
    }

    textarea:focus,
    input[type="text"]:focus,
    input[type="password"]:focus,
    input[type="datetime"]:focus,
    input[type="datetime-local"]:focus,
    input[type="date"]:focus,
    input[type="month"]:focus,
    input[type="time"]:focus,
    input[type="week"]:focus,
    input[type="number"]:focus,
    input[type="email"]:focus,
    input[type="url"]:focus,
    input[type="search"]:focus,
    input[type="tel"]:focus,
    input[type="color"]:focus,

    .uneditable-input:focus {   
        border-color: rgba(31, 46, 88, 0.8);
        box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset, 0 0 8px rgba(31, 46, 88, 0.8);
        outline: 0 none;
    }

    .btn {
        background-color: #ebebeb;
        color: #000;
        border-color: #bfc9d8;
        width: 180px;
        height: 45px;
    }

    .btn:active {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:hover {
        background-color: #232F3E;
        color: #fff;
        box-shadow: none;
    }

    .btn:focus {
        box-shadow: none;
    }

    .border {
        border-style: solid;
        background-color: #f7f7f7f5;
        border-radius: 5px;
        margin-top: 50px;
    }

    .custom-router-link {
        margin-top: 20px;
        color: #333;
        text-decoration: none;
        font-size: 14px;
        display: inline-block;
        transition: color 0.3s ease;
        font-weight: bold;
    }

    .custom-router-link:hover {
        color: #007bff;
        font-weight: bold;
    }

</style>